#ifndef Polygone_HPP
#define Polygone_HPP

#include "Shape.hpp"


class Polygone : public Shape{

	private:
		//Donnée membres
		Point *a;
		Point *b;
		Point *c;
		size_t nbSommets;
	
	public:
		//Constructeur
		Polygone(ulong _color, int _thick, uint _x, uint _y, uint _ax, uint _ay,
    uint _bx, uint _by, uint _cx, uint _cy, size_t _nbSommets);
		
		//Constructeur par copie
		Polygone(const Polygone& orig);
		
		//Constructeur à partir d'un fichier texte
		Polygone(istream& is);
		
		//Destructeur
		~Polygone();
		
		//empecher la surcharge d'opérateur d'affectation
		//Polygone& operator=(const Polygone&)= delete;
		//***********************************
		// DECLARATION DES FONCTIONS MEMBRES*
		//***********************************
		//getter
		inline size_t getNbSommets() const {return nbSommets;}
		inline Point* getA() const {return a;}
		inline Point* getB() const {return b;}
		inline Point* getC() const {return b;}

		//Setter	
        inline void setNbSommets(size_t n) {nbSommets=n;}		
		inline void setA(uint _x, uint _y) {getA()->setXY(_x,_y);}
		inline void setB(uint _x, uint _y) {getB()->setXY(_x,_y);}
		inline void setC(uint _x, uint _y) {getC()->setXY(_x,_y);}

		void newPoint(uint _x, uint _y);

		void draw(EZWindow& window, bool isActive=false) const;
		void drawPolygone(EZWindow& window, bool isActive=false) const;

		void setSize(uint _w, uint _h, Point* p);
		
        //double side(Point a, Point b);
		double perimeter()const;
		
		void write(ostream& os) const ;
		//***************************************
		// DECLARATION DES FONCTIONS NON MEMBRES*
		//***************************************
		
	
};



#endif
