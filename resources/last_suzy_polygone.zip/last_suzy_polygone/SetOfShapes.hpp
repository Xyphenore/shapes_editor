#ifndef SETOFSHAPES_HPP
#define SETOFSHAPES_HPP

#include "Shape.hpp"

class SetOfShapes {

	private:
		//Données membres
		size_t maxShapes;
		size_t nbShapes;
		Shape ** shapes;		//tableau de pointeurs sur des instances de Shape
		// Shape * shapes -> pointeur sur UN shape
     	// Shape ** shapes -> tableau dyn de pointeur
	public:
		//Constructeur
		SetOfShapes(size_t _maxShapes=20);
		
		//Destructeur
		~SetOfShapes();
		
		SetOfShapes(const SetOfShapes&) = delete; //Interdiction de construire une copie
		//***********************************
		// DECLARATION DES FONCTIONS MEMBRES*
		//***********************************	
		void add(Shape* _pshape);	
		void del(size_t n);	
		
		
		// Vérifie si les coordonnées en paramètre (position du curseur de la souris)
		// sont au dessus des coordonnées de l'instance de shape renvoie une adresse ou nullptr
		Shape* isOver(uint mouse_x, uint mouse_y) const;
		
		Shape* isResizing(uint mouse_x, uint mouse_y) const;	

		void draw(EZWindow& window) const;
		
		void save(ostream& os)const;
		
		void load(istream& is);
		void m_load(istream& is);
			
		//***************************************
		// DECLARATION DES FONCTIONS NON MEMBRES*
		//***************************************
		//Surcharge opérateur<<
		friend ostream& operator<<(ostream& os, const SetOfShapes& orig);

};

#endif
