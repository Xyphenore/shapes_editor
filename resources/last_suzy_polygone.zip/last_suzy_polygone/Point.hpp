#ifndef POINT_HPP
#define POINT_HPP

#include "ez-draw++.hpp"

typedef unsigned int uint;
typedef unsigned long int ulong;

constexpr double Pi = 3.1415;


class Point {

	private :
		//Données membres
		static const uint size;
		uint x;
		uint y;

		bool select;

	
	public :
		//***********************************
		//		CONSTRUCTEURS/DESTRUCTEUR   	*
		//***********************************
			
		//Constructeur à 2 paramètres
		Point(uint _x, uint _y);

		//Constructeur de copie
		Point(const Point& orig);
		
		// pour construire une instance à partir du fichier texte de sauvegarde ?
		Point( istream& is);
		
		//Destructeur
		~Point();
	
		//***********************************
		// DECLARATION DES FONCTIONS MEMBRES*
		//***********************************
		// Interdiction de surcharger opérateur d'affectation
		//Point& operator=(const Point&) = delete;

		
		//Getter
		inline uint getX() const {return x;}
		inline uint getY() const {return y;}
		inline bool getSelect() const {return select;}
		
		//Setter
		inline void setXY(uint _x, uint _y) {x=_x; y=_y;}
		inline void setSelect(bool _select) {select=_select;}
		
		// Vérifie si les coordonnées en paramètre 
		// (position du curseur de la souris)
		// sont au dessus des coordonnées de l'instance de point
		bool isOver(uint mouse_x, uint mouse_y) const;
		
		void draw(EZWindow& window, bool isActive =false) const;
		void drawAnchor(EZWindow& window, bool isActive =false) const;
		//***************************************
		// DECLARATION DES FONCTIONS NON MEMBRES*
		//***************************************
		//Surcharge opérateur<<
		friend ostream& operator<<(ostream& os, const Point& orig);
		friend istream& operator>>(istream& is, Point& dest);	
	
};
#endif
