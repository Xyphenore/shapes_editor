#ifndef SHAPE_HPP
#define SHAPE_HPP

//Pour la Factory avancée
#include <string>
#include <map>
#include <vector>


#include "Point.hpp"

class Shape{

	private :
		//Données membres
		ulong color;
		int thick;
		Point anchor;
		bool selected;
		bool resizing;
		size_t id;
		
		bool actived;
		vector<Point*>sommets;

		// Ajout pour la Factory avancée
		
		// typedef définit un nouveau type "factory_function" qui 
		// correspond à un pointeur sur une fonction
		// prend une ref à un flux d'entrée en parametre ístream
		// retourne l'adresse d'une nouvelle instance dérivée de Shape
		typedef Shape* (*factory_function)(istream& is);
		
		// Constitue un ensemble d'association entre une chaine
		// et une adresse de factory_function
		// propre à la classe, donc static.
		static map<string, factory_function> factories;
	
	public :
		//***********************************
		//		CONSTRUCTEURS/DESTRUCTEUR   	*
		//***********************************
		//Constructeur par défaut
		Shape(ulong _color,int _thick, uint p_x, uint p_y);

		//Constructeur de copie
		Shape(const Shape& orig);
		
		// Constructeur à partir du fichier texte
		Shape(istream& is);
		
		//Destructeur
		// Virtual indique au compilateur qu'on choisira 
		// le destructeur de la classe fille concerné
		// au moment de l'execution.
		virtual ~Shape();
	
		void addPoint(Point* p);
		virtual void newPoint(uint _x, uint _y);
		//Pour la Factory avancée
		
		// Patron de fonction membre de la classe
		// associe dans le map, à la chaine "className", une lambda qui crée
		// dynamiquement une instance de la classe "classtype" à partir du flux d'entrée
		// et retourne son adresse
		template<typename classType>
		static void register_factory_function(const char* className)
		{ factories[className] = [](istream& is)->Shape* {return new classType(is);}; }
		
		static void print_registered_factory_functions(ostream& os);
	
	
		//***********************************
		// DECLARATION DES FONCTIONS MEMBRES*
		//***********************************
		//empecher la surcharge d'opérateur d'affectation
		//Shape& operator=(const Shape&)= delete;
		
		//Getter
		inline int getThick() const {return thick;}
		inline ulong getColor() const {return color;}
		inline Point getAnchor() const {return anchor;}
		inline bool getSelected() const {return selected;}
		inline bool getResizing() const {return resizing;}	
		inline size_t getId() const {return id;}
		
		inline bool getActived() const {return actived;}
		Point* getSommet() const;	
		inline vector<Point*> getV() const {return sommets;}

		//Setter
		inline void setThick(int _thick) {thick=_thick;}
		inline void setColor(ulong _color) {color=_color;}
		inline void setAnchor(uint _x, uint _y) {anchor.setXY(_x,_y);}
		inline void setSelected(bool _selected) {selected=_selected;}
		inline void setResizing(bool _resizing) {resizing=_resizing;}
		inline void setId(size_t _id) {id=_id;} 
		
		inline void setActived(bool _actived) {actived=_actived;}
		void setSommet(uint _x, uint _y);
		void setSommets(uint _x, uint _y);
		void moveSommets(uint _x, uint _y);

		// Vérifie si les coordonnées en paramètre (position du curseur de la souris)
		// sont au dessus des coordonnées de l'instance de point
		bool isOver(uint mouse_x, uint mouse_y) const;	
		Point* isOver2(uint mouse_x, uint mouse_y) const;
		// Vérifie si les coordonnées en paramètre (position du curseur de la souris)
		// sont au dessus des coordonnées de l'instance de point
		bool isResizing(uint mouse_x, uint mouse_y) const;	
		
		//Fonction virtuelle pure
		//Rend la classe Shape abstraite, cad on ne peut pas l'instancier.
		// Donc on ne l'implante pas dans Shape.cpp
		virtual double perimeter() const =0;
		
		//Fonction virtuelle
		// On ne l'implante pas entièrement dans Shape.cpp
		// c'est dans les classe filles qu'elle sera implantée en entier
		virtual void draw(EZWindow& window, bool isActive=false) const;
		
		virtual void setSize(uint _h, uint _y, Point* p);
		
		static Shape* load(istream& is);
		static Shape* m_load(istream& is);
		 
		
			protected:
		// Fonction virtuelle pure
		// Donc on ne l'implante pas dans Shape.cpp
		virtual void write(ostream& os) const =0;	
		
		
		//***************************************
		// DECLARATION DES FONCTIONS NON MEMBRES*
		//***************************************
		//Surcharge opérateur<<
		friend ostream& operator<<(ostream& os, const Shape& orig);

};


#endif
