#include<iostream>
#include<stdexcept>

using namespace std;


#include "SetOfShapes.hpp"

//Constructeur
SetOfShapes::SetOfShapes(size_t _maxShapes)
	: maxShapes(_maxShapes),nbShapes(0),shapes(nullptr)
	{ 
		cerr << "SetOfShapes::SetOfShapes(" << maxShapes << ")" << endl;
		shapes = new Shape*[maxShapes];
		for(size_t i=0; i< maxShapes; i++)
			shapes[i]=nullptr;
	}
	
//Destructeur
SetOfShapes::~SetOfShapes()
{
	cerr << "SetOfShapes::~SetOfShapes()" << endl;
	for(size_t i=0; i< nbShapes; i++)
	{
		delete shapes[i];
		shapes[i]=nullptr;
	}
		
	delete [] shapes;
	shapes=nullptr;
}

//***********************************
// DEFINITION DES FONCTIONS MEMBRES *
//***********************************	
void SetOfShapes::add(Shape* _pshape)
{
	if (nbShapes >= maxShapes)
	{
		size_t resize = 2*maxShapes;
		Shape ** data = new Shape* [resize];
		for(size_t i=0; i< resize; i++)
			data[i]=nullptr;
		
		for (size_t i = 0; i <nbShapes ; i++)
			data[i] = shapes[i];
		
		maxShapes =  resize;
		delete [] shapes;
		shapes = data ;
	}
	_pshape->setId(nbShapes);	
	shapes[nbShapes] = _pshape;
	nbShapes++;
}


// TODO à améliorer pour éviter la recopie de tableau
// piste de la liste à explorer.
void SetOfShapes::del(size_t n)
{	
	if (nbShapes >= 1)
	{		
		Shape ** data = new Shape* [maxShapes];
		for(size_t i=0; i< maxShapes; i++)
			data[i]=nullptr;
			
		for (size_t i = 0; i <n ; i++)
			data[i] = shapes[i];
			
		for (size_t i = n; i <nbShapes-1 ; i++)
		{
			data[i] = shapes[i+1];
			if(data[i] != nullptr) 
				data[i]->setId(i);
		}

		delete [] shapes ;
		shapes = data ;
		
		nbShapes--;
	}
	//TODO try catch
	//else throw exception out_of_range ?
}


Shape* SetOfShapes::isOver(uint mouse_x, uint mouse_y) const
{
    for(size_t i=0; i<nbShapes; i++)
	    if(shapes[i]->getAnchor().isOver(mouse_x, mouse_y))
			return shapes[i];
		
	return nullptr;
}


//TODO à creuser
Shape* SetOfShapes::isResizing(uint mouse_x, uint mouse_y) const
{
    for(size_t i=0; i<nbShapes; i++)
	{	
		cerr << "Bool set of shape = " << shapes[i]->isResizing(mouse_x, mouse_y) << endl;
	    if(shapes[i]->isResizing(mouse_x, mouse_y))
			return shapes[i];
	}


	return nullptr;
}

void SetOfShapes::draw(EZWindow& window) const
{
	for(size_t i=0; i<nbShapes; i++)
		shapes[i]->draw(window);
}

void SetOfShapes::save(ostream& os)const
{
	os << nbShapes << endl;
	os << *this; // appelle << sur l'instance courante renvoyée par this et on veut pas l'adresse mais le contenu donc *this
}


//factory: fonction membre de classe 
// qui fabrique un pointeur sur sa classe
void SetOfShapes::load(istream& is)
{
	size_t nb_shapes; //variable locale et non la donnée membres
	is >> nb_shapes;
	for(size_t i=0; i< nb_shapes; i++)
		add(Shape::load(is)); // Fonction static donc on l'appelle sur la classe t non sur une instance
}

void SetOfShapes::m_load(istream& is)
{
	add(Shape::load(is)); // Fonction static donc on l'appelle sur la classe t non sur une instance
}

//***********************************
// DEFINITION DES FONCTIONS MEMBRES *
//***********************************

//Surcharge opérateur<<
ostream& operator<<(ostream& os, const SetOfShapes& _sOfShape)
{

	for(size_t i=0; i<_sOfShape.nbShapes; i++)
		//_sOfShape.shapes[i]->write(os);
		os << *_sOfShape.shapes[i] << endl;
	return os;
}
