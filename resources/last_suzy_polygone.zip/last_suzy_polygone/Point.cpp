#include<iostream>
#include<stdexcept>

using namespace std;


#include "Point.hpp"

const uint Point::size = 3;
//***********************************
//		CONSTRUCTEURS/DESTRUCTEUR   	*
//***********************************

//Constructeur
Point::Point(uint _x, uint _y)
    : x(_x),y(_y),select(false)
    {// cerr << "Point::Point(" << x << ',' << y << ")" << endl;
     }

// Constructeur par copie
Point::Point(const Point& orig)
    :x(orig.x), y(orig.y), select(false)
    { //cerr << "Point(const Point& orig)" << endl; 
    }

//Constructeur à partir d'un fichier
Point::Point(istream& is)
    :x(0),y(0),select(false)
    {  is >> x >> y ;}

//Destructeur
Point::~Point()
    {// cerr << "~Point()" << endl; 
    }

//***********************************
// DEFINITION DES FONCTIONS MEMBRES *
//***********************************
	
// Vérifie si les coordonnées en paramètre
// cad position curseur souris
// sont au dessus des coord de l'instance de Point
bool Point::isOver(uint mouse_x, uint mouse_y) const
{   
    uint tmp_x = (mouse_x<x? x-mouse_x:mouse_x-x );
    uint tmp_y = (mouse_y<y? y-mouse_y:mouse_y-y ); 
    
    return ((tmp_x <= size) && (tmp_y <= size));
}
		
void Point::draw(EZWindow& window, bool isActive) const
{ window.fillCircle(x-size, y-size, x+size, y+size); }

void Point::drawAnchor(EZWindow& window, bool isActive) const
{ window.drawCircle(x-size, y-size, x+size, y+size); }

//***************************************
// DEFINITION DES FONCTIONS NON MEMBRES *
//***************************************
//Surcharge opérateur<<
ostream& operator<<(ostream& os, const Point& orig)
{
	os << orig.getX() << ' ' << orig.getY();
	return os;
}

//Surcharge opérateur>>
istream& operator>>(istream& is, Point& dest)
{	
	uint x;
	uint y;
	is >> x >> y;
	dest.setXY(x,y);
	
	return is;
}	
	
