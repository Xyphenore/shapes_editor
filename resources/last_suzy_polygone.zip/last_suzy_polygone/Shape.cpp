#include <iostream>
#include <stdexcept>

// Pour utiliser un ostringstream
#include <sstream>


using namespace std;

#include "Shape.hpp"




//***********************************
//		CONSTRUCTEURS/DESTRUCTEUR   	*
//***********************************

//Constructeur par défaut
Shape::Shape(ulong _color, int _thick, uint _x, uint _y)
	: color(_color),thick(_thick),anchor(_x,_y),selected(false),
	 resizing(false), actived(false)
	{
		cerr << "Shape::Shape(" << color << ',' << _thick << ',' << _x << ',' << _y << ")" << endl;
	}

//Constructeur de copie
Shape::Shape(const Shape& orig)
	: color(orig.color), thick(orig.thick),anchor(orig.anchor),
	 selected(false), resizing(false), actived(false), sommets(orig.sommets)
	{
		cerr << "Shape::Shape(const Shape& orig)" << endl;
	}


// pour construire une instance à partir d'un flux >>
Shape::Shape(istream& is)
	: color(ez_black),thick(1), anchor(0,0), selected(false), 
	resizing(false), actived(false)
	{ 
		uint loc_x;
		uint loc_y;
		cerr << "Shape::Shape(const istream& is)" << endl;
		is >> color >> thick >> loc_x >> loc_y;
		setAnchor(loc_x,loc_y);
		
	}

//Destructeur
// Virtual indique au compilateur qu'on choisira 
// le destructeur de la classe fille concerné
// au moment de l'execution.
Shape::~Shape()
	{
		cerr << "~Shape()" << endl;

		// Destruction des points créés
		for (size_t i=0; i<sommets.size(); i++)
			delete sommets.at(i);
		// appelle à l'execution le destructeur de la classe fille concernée
	}
	
	
//***********************************
// DEFINITION DES FONCTIONS MEMBRES *
//***********************************
void Shape::addPoint(Point* p)
{
	sommets.push_back(p);
}

void Shape::newPoint(uint _x, uint _y)
{}

Point* Shape::getSommet() const
{
	for (size_t i=0; i<sommets.size(); i++)
		if(sommets.at(i)->getSelect())
			return sommets.at(i);

	return nullptr;
}

void Shape::setSommet(uint _x, uint _y)
{
	for (size_t i=0; i<sommets.size(); i++)
	{
		if(sommets.at(i)->getSelect())
			sommets.at(i)->setXY(_x, _y);
	}
}

void Shape::setSommets(uint _x, uint _y)
{
	for (size_t i=0; i<sommets.size(); i++)
		sommets.at(i)->setXY(_x, _y);
}

void Shape::moveSommets(uint _x, uint _y)
{
	for (size_t i=0; i<sommets.size(); i++)
	{
		sommets.at(i)->setXY(((sommets.at(i)->getX()-anchor.getX())+_x),
		((sommets.at(i)->getY()-anchor.getY())+_y));
	}
}

//Pour la Factory avancée

//Crée l'instance du dictionnaire associatif déclaré dans Shape.hpp
//Constiendra la liste associations chaine + fonction factory associé à cette chaine
map<string, Shape::factory_function> Shape::factories;	

// liste toutes les formes qui ont fait enregistrer une factory dans le map.
void Shape::print_registered_factory_functions(ostream& os)
{
	os << "Classes dont les factories ont été enregistrées associées à une chaine de typage :" << endl;
	
	// Boucle for généralisée
	// à chaque itération e sera une ref à l'une des paires
	// contenue dans la factory
	// e.first permet juste d'étudier son bon fonctionnement
	for(const auto& e : factories)
		os << e.first << endl;
}
// Le mot clé auto indique au compilateur d’utiliser l’expression d’initialisation
// d’une variable déclarée, ou d’un paramètre d’expression lambda, 
// pour déduire son type.


// Vérifie si les coordonnées en paramètre (position du curseur de la souris)
// sont au dessus des coordonnées de l'ancre de la forme
bool Shape::isOver(uint mouse_x, uint mouse_y) const
{ return anchor.isOver(mouse_x, mouse_y); }


Point* Shape::isOver2(uint mouse_x, uint mouse_y) const
{ 	
	for (size_t i=0; i<sommets.size(); i++)
		if(sommets.at(i)->isOver(mouse_x, mouse_y))
			return (sommets.at(i)); 
	
	return nullptr;
}	
	
// Vérifie si les coordonnées en paramètre (position du curseur de la souris)
// sont au dessus des coordonnées de l'ancre de redimension de la forme
bool Shape::isResizing(uint mouse_x, uint mouse_y) const
{ 	
	bool tmp=false;
	for (size_t i=0; i<sommets.size(); i++)
		if(sommets.at(i)->isOver(mouse_x, mouse_y))
			tmp=true;
	
	return tmp;			
}


// Fonction virtual, prépare juste la couleur pour l'instance fille 
// qui va hériter de shape
void Shape::draw(EZWindow& window, bool isActive) const 
{ 
	if(!actived)
	{
		window.setColor(color); 
		window.setThick(thick);
	}
	else
	{
		window.setColor(ez_red); 
		window.setThick(getThick()+1);
	}
	if(sommets.size() >=1)
	{
		for (size_t i=0; i<sommets.size(); i++)
			sommets.at(i)->draw(window);
	}
}


//Charge une forme à partir d'un fichier texte et crée une instance de cette forme
// Ne crée pas une instance de Shape mais une instance qui hérite de Shape	
Shape* Shape::load(istream& is)
{
	string typeName;
	is >> typeName;
	try
	{
		factory_function f = factories.at(typeName);
		Shape* shape = (*f)(is);
		return shape;
	}
	catch (std::range_error& e)
	{
		std::ostringstream oss;
		oss << "Chaine de type de forme inconnue \"" << typeName 
		<< "\". Impossible de créer cette forme et donc de continuer. Abandon.";
		throw std::runtime_error(oss.str());
	}
}


// fonction virtuelle
void Shape::setSize(uint x, uint y, Point* p)
{ }
		
//***************************************
// DEFINITION DES FONCTIONS NON MEMBRES *
//***************************************
//Surcharge opérateur<<
ostream& operator<<(ostream& os, const Shape& orig)
{
	//os << orig.color << orig.anchor.getX() << orig.anchor.getY() << orig.getSelected();
	// peut-être que j'ai pas besoin des getX() getY() car la classe point 
	// a aussi sa propre surcharge << 
	orig.write(os);
	return os;
}
		
//Fonction virtuelle pure donc on ne l'implante pas	
//void write(ostream& os) const =0 {}


