// MyWindow.hpp

#ifndef MYWINDOW_HPP
#define MYWINDOW_HPP

#include "SetOfShapes.hpp"

class MyWindow : public EZWindow {
  SetOfShapes shapes;
  Shape  *pshape;
  Point *ppoint;
  // pour permettre la saisie d'une forme
  string saisie = "";

  // Pour afficher un message d'erreur sur la fenetre
  string str ="";
  
  static bool needInitialization;
  static bool mouse_shape;
  static bool err;
  
 public:
  MyWindow(int w, int h,const char *name);
  ~MyWindow();
  void expose();
  void keyPress(EZKeySym keysym);
  void buttonPress(int mouse_x,int mouse_y,int button);
  void motionNotify(int mouse_x,int mouse_y,int button);
  void buttonRelease(int mouse_x,int mouse_y,int button);

  int saisie_forme (EZKeySym keysym, string& saisie);
};

#endif
