// MyWindow.cpp
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

#include "ez-draw++.hpp"
#include "MyWindow.hpp"

#include "SetOfShapes.hpp"

#include "Point.hpp"   // Uniquement pour le constructeur qui peuple la fenêtre
/* #include "Ellipse.hpp" // avec quelques shapes.
#include "Circle.hpp"
#include "Rectangle.hpp"
#include "Square.hpp"
#include "Triangle.hpp"*/
#include "Polygone.hpp"


bool MyWindow::needInitialization=true ;
bool MyWindow::mouse_shape=false;
bool MyWindow::err=false;

MyWindow::MyWindow(int w, int h,const char *name)
 : EZWindow(w,h,name),shapes(20),pshape(nullptr),ppoint(nullptr)
{
	if(needInitialization)
	{
		needInitialization=false;
		/* Shape::register_factory_function<Rectangle>("Rectangle");
		Shape::register_factory_function<Square>("Square");
		Shape::register_factory_function<Circle>("Circle");
		Shape::register_factory_function<Ellipse>("Ellipse");
          Shape::register_factory_function<Triangle>("Triangle"); */
          Shape::register_factory_function<Polygone>("Polygone");
		Shape::print_registered_factory_functions(cout);
	}

}

MyWindow::~MyWindow()
{ cerr << "MyWindow::~MyWindow()" << endl;}

void MyWindow::expose()
{
 shapes.draw(*this);
 setColor(ez_black);
 drawText(EZAlign::TL,3,3,"h : affiche l'aide sur la console");
 if(mouse_shape)
     drawText(EZAlign::TL, 3, 20, "Forme : "+saisie+"_");
 if(err)
     drawText(EZAlign::TL, 3, 20, str);
}



void MyWindow::buttonPress(int mouse_x,int mouse_y,int button)
{
 if(button==1) // bouton gauche de la souris
 {
     if(pshape!=nullptr) pshape->setSelected(false);
     pshape = shapes.isOver(mouse_x,mouse_y);
     if(pshape!=nullptr) pshape->setSelected(true);
     
 }
 
 if(button==3) // bouton droit de la souris
 {
	if(pshape!=nullptr) pshape->setResizing(false);
	pshape = shapes.isResizing(mouse_x,mouse_y);
     if(pshape!=nullptr) pshape->setResizing(true);
     if(ppoint!=nullptr) ppoint->setSelect(false);
     if(pshape!=nullptr) ppoint = pshape->isOver2(mouse_x,mouse_y);
     if(ppoint!=nullptr) ppoint->setSelect(true);
 }
 
 if(button==2) // bouton central de la souris
 {
	if(pshape!=nullptr) pshape->setSelected(false);
	pshape = shapes.isOver(mouse_x,mouse_y);
	if(pshape!=nullptr) pshape->setSelected(true);
 }

}


// MAJ suzy, ajout du traitement du point de resize
// Deplacement de la souris :
void MyWindow::motionNotify(int mouse_x,int mouse_y,int button)
{
	if(button == 1 && pshape != nullptr) // Si on clique sur l'anchor d'une shape
	{
		pshape->setActived(true);
		pshape->draw(*this);
          pshape->moveSommets(mouse_x,mouse_y); // on bouge les autres sommets		
          pshape->setAnchor(mouse_x,mouse_y); // on bouge l'ancre.	
	}
	
	if(button == 3 && pshape != nullptr && ppoint != nullptr) // Si on clique sur l'ancre de resize
	{	
		pshape->setActived(true);
          ppoint->setSelect(true);
		pshape->draw(*this);
		
          ppoint->setXY(mouse_x,mouse_y); // on bouge son point de resize
		int loc_w = (ppoint->getX())-(pshape->getAnchor().getX());
		int loc_h = (ppoint->getY())-(pshape->getAnchor().getY());
		
		pshape->setSize(loc_w,loc_h, ppoint); // On redimensionne la forme
	}

 sendExpose();
}

// MAJ suzy, ajout du traitement de l'ancre de resize
void MyWindow::buttonRelease(int mouse_x,int mouse_y,int button)
{
	if(button == 1 && pshape != nullptr) // Si on clique sur l'anchor d'une shape
	{
		pshape->setActived(false);
          pshape->moveSommets(mouse_x,mouse_y);
		pshape->setAnchor(mouse_x,mouse_y);
	}
		
	if(button == 3 && pshape != nullptr && ppoint!=nullptr) // Si on clique sur l'ancre de resize avec le bouton droit de la souris
	{
		pshape->setActived(false);
          ppoint->setSelect(false);
          ppoint->setXY(mouse_x,mouse_y);
		int loc_w = (ppoint->getX())-(pshape->getAnchor().getX());
		int loc_h = (ppoint->getY())-(pshape->getAnchor().getY());
		
		pshape->setSize(loc_w,loc_h, ppoint); // On redimensionne la forme
	}

     /* if(button == 8 && pshape == nullptr)
	{
          err=false;
          mouse_shape=true;
	} */

     if(button == 8)
	{
          if(pshape == nullptr)
          {
               pshape=new Polygone(ez_black,1,mouse_x,mouse_y,getWidth()/2,getHeight()/2-50,
               getWidth()/2-25,getHeight()/2-30,getWidth()/2+25,getHeight()/2-30,3);
               shapes.add(pshape);
          }
          else
               pshape->newPoint(mouse_x,mouse_y);
	}
	
	if(button == 2 && pshape != nullptr) // Si on clique sur l'anchor  avec le bouton central de la souris
	{
		shapes.del(pshape->getId());
		delete pshape;
		pshape=nullptr;
	}

 sendExpose();
}


void MyWindow::keyPress(EZKeySym keysym) // Une touche du clavier a ete enfoncee ou relachee
{    
     // test Suzy
     // Permet de saisir le nom d'une forme et de charger la forme adéquate
     if (saisie_forme (keysym, saisie) == 1)
    {
        istringstream iss;
        iss >> saisie;
        ifstream f(saisie+".txt");
        try
        {
             shapes.m_load(f);
        }
        catch(const std::exception& e)
        {
          mouse_shape=false;
          err=true;
          str="Vous avez saisie une forme invalide";
        }   
    }
     
     if(!mouse_shape)
     {    
          switch (keysym)
          {
          case EZKeySym::Escape:
          case EZKeySym::q :       EZDraw::quit (); break;
          case EZKeySym::E: cout << shapes; break;
          case EZKeySym::S: {ofstream f("shapes.txt");shapes.save(f);} break;
          case EZKeySym::L: {ifstream f("shapes.txt");shapes.load(f);} break;
          case EZKeySym::_0: if(pshape) pshape->setColor(ez_black);   break;
          case EZKeySym::_1: if(pshape) pshape->setColor(ez_grey);    break;
          case EZKeySym::_2: if(pshape) pshape->setColor(ez_red);     break;
          case EZKeySym::_3: if(pshape) pshape->setColor(ez_green);   break;
          case EZKeySym::_4: if(pshape) pshape->setColor(ez_blue);    break;
          case EZKeySym::_5: if(pshape) pshape->setColor(ez_yellow);  break;
          case EZKeySym::_6: if(pshape) pshape->setColor(ez_cyan);    break;
          case EZKeySym::_7: if(pshape) pshape->setColor(ez_magenta); break;
          case EZKeySym::h:
          cout << "q : quitter" << endl
               << "h : cette aide" << endl
               << "E : écrit la liste des formes sur la console" << endl
               << "S : sauve la liste des formes sur disque" << endl
               << "L : charge la liste des formes depuis le disque" << endl
               << "+ : augmente l'épaisseur"    << endl
               << "- : diminue l'épaisseur"     << endl
               << "0 : met en noir la forme"    << endl
               << "1 : met en gris la forme"    << endl
               << "2 : met en rouge la forme"   << endl
               << "3 : met en vert la forme"    << endl
               << "4 : met en bleu la forme"    << endl
               << "5 : met en jaune la forme"   << endl
               << "6 : met en cyan la forme"    << endl
               << "7 : met en magenta la forme" << endl
               << "p : crée un polygone" << endl
/*                << "r : crée un rectangle" << endl
               << "e : crée une ellipse" << endl
               << "s : crée un carré" << endl
               << "c : crée un cercle" << endl
               << "t : crée un triangle" << endl */
               ;
          break;
          /*case EZKeySym::p: 
                    shapes.add(new Polygone(ez_black,1,getWidth()/2-25,getHeight()/2-25,5));
          break;
           case EZKeySym::r: 
                    shapes.add(new Rectangle(ez_black,1,getWidth()/2-25,getHeight()/2-25,getWidth()/2+25,getHeight()/2+25));
          break;
          
          case EZKeySym::e: 
                    shapes.add(new Ellipse(ez_black,1,getWidth()/2-25,getHeight()/2-15,50,30)); 
          break;
          
          case EZKeySym::s: 
                    shapes.add(new Square(ez_black,1,getWidth()/2-25,getHeight()/2-25,50)); 
          break;
          
          case EZKeySym::c: 
                    shapes.add(new Circle(ez_black,1,getWidth()/2-25,getHeight()/2-25,25)); 
          break;

          case EZKeySym::t: 
                    shapes.add(new Triangle(ez_black,1,getWidth()/2,getHeight()/2-50,getWidth()/2-25,getHeight()/2-30,getWidth()/2+25,getHeight()/2-30)); 
          break; */
          
          //Test Suzy
          case EZKeySym::minus: if(pshape) pshape->setThick(pshape->getThick()-1); break;
          
          case EZKeySym::plus: if(pshape) pshape->setThick(pshape->getThick()+1); break;
          
          default:
          break;
          }
    }
 sendExpose();
}

int MyWindow::saisie_forme (EZKeySym keysym, string& saisie)
{
     switch (keysym) 
     {
          case EZKeySym::Return : 
               mouse_shape=false; 
               return 1;  

          case EZKeySym::Escape : 
               saisie.erase(saisie.begin(),saisie.end());
               sendExpose();
          break;    

          case EZKeySym::BackSpace :
               if (saisie.length()==0 ) break;
               saisie.pop_back();
               sendExpose();
          break;      

          default :                                
               if (currentEvent().keyCount() != 1) break;
               saisie.push_back(currentEvent().keyString()[0]);
               sendExpose();
               break;
     }
     return 0;
}
