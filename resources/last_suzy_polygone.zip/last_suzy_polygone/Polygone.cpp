#include<iostream>
#include<stdexcept>

using namespace std;

#include "Shape.hpp"
#include "Polygone.hpp"

	Polygone::Polygone(ulong _color, int _thick, uint _x, uint _y, uint _ax, uint _ay,
    uint _bx, uint _by, uint _cx, uint _cy, size_t _nbSommets)
	: Shape(_color,_thick, _x, _y), a(nullptr), b(nullptr), c(nullptr), nbSommets(_nbSommets)
    {
    //new Polygone(ez_black,1,getWidth()/2,getHeight()/2-50,
    // getWidth()/2-25,getHeight()/2-30,
    // getWidth()/2+25,getHeight()/2-30)); 
       cerr <<"Polygone::Polygone( " << getColor() << ',' << getThick() << ',' << _x << ',' << _y
		 << ',' << _ax << ',' << _ay << ','<< _bx << ',' << _by << ','
         << _cx << ',' << _cy << ','  << nbSommets <<  ")" << endl;

        a = new Point(_ax,_ay);
		Shape::addPoint(a);
        
        b = new Point(_bx,_by);
		Shape::addPoint(b);

        c = new Point(_cx,_cy);
		Shape::addPoint(c);

        uint mov_x = (_ax+_bx+_cx)/3;
        uint mov_y = (_ay+_by+_cy)/3;
        setAnchor(mov_x, mov_y);

        cerr << "nb points = " << getV().size() << endl;
    }
		
	//Constructeur par copie
	Polygone::Polygone(const Polygone& orig)
    : Polygone(orig.getColor(),orig.getThick(), orig.getAnchor().getX(), orig.getAnchor().getY(),
    orig.getA()->getX(), orig.getA()->getY(), orig.getB()->getX(), orig.getB()->getY(), 
	orig.getC()->getX(), orig.getC()->getY(), orig.getNbSommets())
    {cerr << "Polygone::Polygone(const Polygone& orig)" << endl;}
		
	//Constructeur à partir d'un fichier texte
	Polygone::Polygone(istream& is)
        : Shape(is), a(nullptr), b(nullptr), c(nullptr), nbSommets(0)
        {   
            is >> nbSommets; 
            for(size_t i=0; i<nbSommets; i++)
            {
                uint tmpx;
                uint tmpy;
                is >> tmpx >> tmpy;
                Shape::addPoint(new Point(tmpx,tmpy));
            }
        }
		
	//Destructeur
	Polygone::~Polygone()
    { cerr << "~Polygone()" << endl; }
		
	//empecher la surcharge d'opérateur d'affectation
	//Polygone& operator=(const Polygone&)= delete;
	//***********************************
	// DECLARATION DES FONCTIONS MEMBRES*
	//***********************************
	void Polygone::newPoint(uint _x, uint _y)
    {
        Shape::addPoint(new Point(_x,_y));
        nbSommets++;
        cerr << nbSommets<< endl;
    }		
		
	void Polygone::draw(EZWindow& window, bool isActive) const
    {
        Shape::draw(window);
	
	    Shape::getAnchor().drawAnchor(window);

	    drawPolygone(window);
    }

    void Polygone::drawPolygone(EZWindow& window, bool isActive) const 
        {
            for (size_t i=0; i<nbSommets-1; i++)
            {  
                window.drawLine(getV().at(i)->getX(), getV().at(i)->getY(),
                getV().at(i+1)->getX(), getV().at(i+1)->getY());
            }
            for (size_t i=nbSommets-1; i<nbSommets; i++)
                window.drawLine(getV().at(i)->getX(), getV().at(i)->getY(), 
                getV().at(0)->getX(), getV().at(0)->getY());     
        }
		
	void Polygone::setSize(uint _w, uint _h, Point* p)
    {
        uint mov_x = (getA()->getX()+getB()->getX()+getC()->getX())/3;
        uint mov_y = (getA()->getY()+getB()->getY()+getC()->getY())/3;
        setAnchor(mov_x, mov_y);

	    //p->setXY(getAnchor().getX()+_w,getAnchor().getY()+_h);
    }
		
    /*double Polygone::side(Point a, Point b)
    {

    }*/

	double Polygone::perimeter()const
    {
        return 0;
    }
		
	void Polygone::write(ostream& os) const 
    {
        os << "Polygone" << ' ' << getColor() << ' ' << getThick() << ' ' << getAnchor() 
        << ' ' << getNbSommets() << ' ';
        for(size_t i=0; i<getNbSommets(); i++)
            os << getV().at(i)->getX() << ' ' << getV().at(i)->getX() << ' ';
    }